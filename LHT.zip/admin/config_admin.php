<?php
    $level_config_layout = '../';
    include_once($level_config_layout.'config.php');
    require_once _DIR_["LIB"]["ADMINS"].'DP.php';
    include_once($level_config_layout.'config_page.php');
    
?>