<script src=<?php echo _DIR_['JS']['USERS'].'jquery-2.2.4.min.js'?>></script>
<script src=<?php echo _DIR_['JS']['USERS'].'popper.min.js'?>></script>
<script src=<?php echo _DIR_['JS']['USERS'].'bootstrap.min.js'?>></script>
<script src=<?php echo _DIR_['JS']['USERS'].'plugins.js'?>></script>
<script src=<?php echo _DIR_['JS']['USERS'].'active.js'?>></script>
<script src=<?php echo _DIR_['JS']['USERS'].'user.js'?>></script>
<script src=<?php echo _DIR_['JS']['USERS'].'cart.js'?>></script>
</body>
</html>