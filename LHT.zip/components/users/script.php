    <!--Core JavaScript file  -->
    <script src=<?php echo _DIR_['PLUGINS']['USERS'].'jquery/jquery.min.js'?>></script>
    <!--bootstrap JavaScript file  -->
    <!-- jQuery UI 1.11.4 -->
    <script src=<?php echo _DIR_['PLUGINS']['USERS'].'jquery-ui/jquery-ui.min.js';?>></script>
    <script src=<?php echo _DIR_['PLUGINS']['USERS'].'bootstrap/js/bootstrap.js'?>></script>
    <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js'></script>
    <script src=<?php echo _DIR_['JS']['USERS'].'main.js'?>></script>
    
    <script src=<?php echo _DIR_['JS']['USERS'].'popper.min.js'?>></script>
    <script src=<?php echo _DIR_['JS']['USERS'].'bootstrap.min.js'?>></script>
    <script src=<?php echo _DIR_['JS']['USERS'].'custom_image.js'?>></script>
    <script src=<?php echo _DIR_['JS']['USERS'].'user.js'?>></script>
    <script src=<?php echo _DIR_['JS']['USERS'].'cart.js'?>></script>

    
    
    
</body>
</html>