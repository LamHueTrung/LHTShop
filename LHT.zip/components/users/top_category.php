<!-- ****** Top Catagory Area Start ****** -->
<section class="top_catagory_area d-md-flex clearfix">
            <!-- Single Catagory -->
            <div class="single_catagory_area d-flex align-items-center bg-img" style="background-image: url(<?php echo _DIR_['IMG']['USERS'].'bg-img/'.'bg-2.jpg';?>)">
                <div class="catagory-content">
                    <h6>Laptop 1</h6>
                    <h2>Laptop 1</h2>
                    <a href="#" class="btn karl-btn">MUA NGAY</a>
                </div>
            </div>
            <!-- Single Catagory -->
            <div class="single_catagory_area d-flex align-items-center bg-img" style="background-image: url(<?php echo _DIR_['IMG']['USERS'].'bg-img/'.'bg-3.jpg';?>)">
                <div class="catagory-content">
                    <h6>Laptop 2</h6>
                    <h2>Laptop 2</h2>
                    <a href="#" class="btn karl-btn">MUA NGAY</a>
                </div>
            </div>
        </section>
        <!-- ****** Top Catagory Area End ****** -->