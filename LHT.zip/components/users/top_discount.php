 <!-- ****** Top Discount Area Start ****** -->
 <section class="top-discount-area d-md-flex align-items-center">
    <!-- Single Discount Area -->
    <div class="single-discount-area">
        <h5>Máy tính chất lượng nhất.</h5>
        <h6>Dell, Asus, Lenovo.</h6>
    </div>
    <!-- Single Discount Area -->
    <div class="single-discount-area">
        <h5>Đồng hồ chất lượng nhất.</h5>
        <h6>Apple, Casio.</h6>
    </div>
    <!-- Single Discount Area -->
    <div class="single-discount-area">
        <h5>Điện thoại chất lượng nhất.</h5>
        <h6>Apple, Xiaomi, Huawei.</h6>
    </div>
</section>
<!-- ****** Top Discount Area End ****** -->